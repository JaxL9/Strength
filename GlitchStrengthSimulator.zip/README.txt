Glitch Strength Simulator
=========================

This is a simple Kivy-based Python project for a strength grinding simulator game.

Files included:
- main.py : main source code

Optional:
- Add your own background.mp3 in the project folder for music playback.

How to build APK using Buildozer (Linux recommended):
-----------------------------------------------------
1. Install Buildozer and dependencies: https://buildozer.readthedocs.io/en/latest/installation.html
2. Initialize buildozer: buildozer init
3. Edit buildozer.spec to set requirements to "kivy"
4. Place main.py and background.mp3 in the project folder
5. Run: buildozer -v android debug
6. The APK will be in bin/

Alternatively, use online services like https://kivy.org/#download or Kodular for building APKs.

import kivy
from kivy.app import App
from kivy.uix.widget import Widget
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.boxlayout import BoxLayout
from kivy.clock import Clock
from kivy.core.audio import SoundLoader

class Pet:
    def __init__(self, name):
        self.name = name
        self.level = 1
        self.exp = 0
        self.multiplier = 1.0

class StrengthGame(Widget):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.strength = 0
        self.pets = [Pet("Rocky")]
        self.punch_power = 1
        self.rebirths = 0
        self.punch_count = 0
        self.glitch_active = False

        self.layout = BoxLayout(orientation='vertical', padding=10, spacing=10)

        self.strength_label = Label(text=f"Strength: {self.strength}", font_size='20sp')
        self.layout.add_widget(self.strength_label)

        self.punch_button = Button(text="Punch the Rock!", font_size='30sp', size_hint=(1, 0.3))
        self.punch_button.bind(on_press=self.punch)
        self.layout.add_widget(self.punch_button)

        self.pets_label = Label(text=self.get_pets_text(), font_size='18sp')
        self.layout.add_widget(self.pets_label)

        self.music = SoundLoader.load('background.mp3')
        if self.music:
            self.music.loop = True
            self.music.play()

        self.add_widget(self.layout)

    def get_pets_text(self):
        texts = []
        for pet in self.pets:
            texts.append(f"{pet.name} Lv.{pet.level} (EXP: {pet.exp})")
        return "\n".join(texts)

    def punch(self, instance):
        self.punch_count += 1
        base_strength = self.punch_power
        pet_bonus = sum(pet.multiplier for pet in self.pets)
        glitch_bonus = 1

        # Glitch every 3rd punch if pet level 1 and 0 exp
        for pet in self.pets:
            if pet.level == 1 and pet.exp == 0 and self.punch_count % 3 == 0:
                glitch_bonus = 5  # 5x glitch multiplier

        gain = base_strength * pet_bonus * glitch_bonus
        self.strength += gain
        self.strength_label.text = f"Strength: {int(self.strength)}"

        # Gain exp for pets (unless glitching)
        if glitch_bonus == 1:
            for pet in self.pets:
                pet.exp += 1
                if pet.exp >= 10:
                    pet.level += 1
                    pet.exp = 0
                    pet.multiplier += 0.5

        self.pets_label.text = self.get_pets_text()

class StrengthApp(App):
    def build(self):
        return StrengthGame()

if __name__ == '__main__':
    StrengthApp().run()
